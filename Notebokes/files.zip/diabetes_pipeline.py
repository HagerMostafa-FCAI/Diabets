"""
Diabetes Dataset Pipeline
==========================
يغطي هذا السكريبت المراحل الأربعة المطلوبة:
1) Dataset & EDA
2) Data Cleaning
3) Data Preprocessing
4) Feature Engineering

الناتج: ملفات صور (EDA plots) + CSV نظيف + CSV بعد الـ Feature Engineering
كلها هتتحفظ في مجلد outputs/
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

# ------------------------------------------------------------------
# إعدادات عامة
# ------------------------------------------------------------------
DATA_PATH = "diabetes.csv"
OUT_DIR = "outputs"
os.makedirs(OUT_DIR, exist_ok=True)

sns.set_style("whitegrid")

# ====================================================================
# 1) DATASET & EDA
# ====================================================================
print("=" * 60)
print("1) DATASET & EDA")
print("=" * 60)

df = pd.read_csv(DATA_PATH)

print(f"\nShape: {df.shape}")
print("\nColumns & dtypes:")
print(df.dtypes)

print("\nFirst rows:")
print(df.head())

print("\nStatistical summary:")
print(df.describe().T)

print("\nMissing values (NaN) per column:")
print(df.isnull().sum())

print("\nOutcome (target) distribution:")
print(df["Outcome"].value_counts())
print(df["Outcome"].value_counts(normalize=True).round(3) * 100, "%")

# بعض الأعمدة الطبية مينفعش تكون قيمتها صفر (ده فعليًا بيانات مفقودة متسجلة كـ 0)
zero_invalid_cols = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
print("\nعدد القيم اللي = 0 في الأعمدة اللي منطقيًا مينفعش تبقى صفر:")
for col in zero_invalid_cols:
    n_zero = (df[col] == 0).sum()
    print(f"  {col:25s}: {n_zero} ({n_zero/len(df)*100:.1f}%)")

# --- Plots ---
# Histograms
df.hist(figsize=(14, 12), bins=20, edgecolor="black")
plt.suptitle("Feature Distributions (Raw Data)", fontsize=16)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/01_histograms.png", dpi=120)
plt.close()

# Correlation heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, fmt=".2f", cmap="coolwarm", square=True)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/02_correlation_heatmap.png", dpi=120)
plt.close()

# Outcome balance
plt.figure(figsize=(5, 4))
sns.countplot(x="Outcome", data=df)
plt.title("Outcome Class Balance (0 = No Diabetes, 1 = Diabetes)")
plt.savefig(f"{OUT_DIR}/03_outcome_balance.png", dpi=120)
plt.close()

# Boxplots (outlier check)
plt.figure(figsize=(14, 8))
for i, col in enumerate(df.columns[:-1], 1):
    plt.subplot(2, 4, i)
    sns.boxplot(y=df[col])
    plt.title(col)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/04_boxplots_outliers.png", dpi=120)
plt.close()

print(f"\n✔ EDA plots saved in '{OUT_DIR}/' (01_histograms, 02_correlation_heatmap, 03_outcome_balance, 04_boxplots_outliers)")

# ====================================================================
# 2) DATA CLEANING
# ====================================================================
print("\n" + "=" * 60)
print("2) DATA CLEANING")
print("=" * 60)

df_clean = df.copy()

# 2.1 استبدال الأصفار غير المنطقية بـ NaN عشان نقدر نتعامل معاها كـ missing values
for col in zero_invalid_cols:
    df_clean[col] = df_clean[col].replace(0, np.nan)

print("\nMissing values بعد تحويل الأصفار الوهمية:")
print(df_clean.isnull().sum())

# 2.2 التعامل مع القيم المفقودة: median imputation لكل عمود (مقسوم حسب Outcome عشان الدقة)
for col in zero_invalid_cols:
    df_clean[col] = df_clean.groupby("Outcome")[col].transform(
        lambda x: x.fillna(x.median())
    )

print("\nMissing values بعد الـ imputation:")
print(df_clean.isnull().sum().sum(), "قيمة مفقودة متبقية")

# 2.3 التحقق من الصفوف المكررة
n_dupes = df_clean.duplicated().sum()
print(f"\nعدد الصفوف المكررة: {n_dupes}")
df_clean = df_clean.drop_duplicates()

# 2.4 معالجة الـ Outliers باستخدام IQR capping (winsorizing) بدل الحذف عشان نحافظ على البيانات
def cap_outliers_iqr(series, factor=1.5):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - factor * iqr, q3 + factor * iqr
    return series.clip(lower, upper)

numeric_cols = df_clean.columns.drop("Outcome")
for col in numeric_cols:
    df_clean[col] = cap_outliers_iqr(df_clean[col])

print("\n✔ تم تنظيف البيانات (missing values + duplicates + outlier capping)")
print(f"Shape بعد التنظيف: {df_clean.shape}")

df_clean.to_csv(f"{OUT_DIR}/diabetes_cleaned.csv", index=False)
print(f"✔ الملف النظيف اتحفظ في '{OUT_DIR}/diabetes_cleaned.csv'")

# ====================================================================
# 3) DATA PREPROCESSING
# ====================================================================
print("\n" + "=" * 60)
print("3) DATA PREPROCESSING")
print("=" * 60)

X = df_clean.drop(columns=["Outcome"])
y = df_clean["Outcome"]

# 3.1 تقسيم البيانات (train/test) قبل الـ scaling عشان نتجنب data leakage
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"\nTrain shape: {X_train.shape} | Test shape: {X_test.shape}")

# 3.2 Feature Scaling باستخدام StandardScaler (fit على التريننج بس)
scaler = StandardScaler()
X_train_scaled = pd.DataFrame(
    scaler.fit_transform(X_train), columns=X_train.columns, index=X_train.index
)
X_test_scaled = pd.DataFrame(
    scaler.transform(X_test), columns=X_test.columns, index=X_test.index
)

print("\nمثال على البيانات بعد الـ scaling (train):")
print(X_train_scaled.describe().T[["mean", "std"]])

print("\n✔ تم الـ preprocessing: train/test split + StandardScaler")

# ====================================================================
# 4) FEATURE ENGINEERING
# ====================================================================
print("\n" + "=" * 60)
print("4) FEATURE ENGINEERING")
print("=" * 60)

df_fe = df_clean.copy()

# 4.1 فئات عمرية (Age groups)
df_fe["AgeGroup"] = pd.cut(
    df_fe["Age"],
    bins=[20, 30, 40, 50, 60, 100],
    labels=["21-30", "31-40", "41-50", "51-60", "60+"],
)

# 4.2 فئات BMI حسب التصنيف الطبي المعروف
df_fe["BMI_Category"] = pd.cut(
    df_fe["BMI"],
    bins=[0, 18.5, 25, 30, 100],
    labels=["Underweight", "Normal", "Overweight", "Obese"],
)

# 4.3 فئات مستوى الجلوكوز
df_fe["Glucose_Category"] = pd.cut(
    df_fe["Glucose"],
    bins=[0, 99, 125, 300],
    labels=["Normal", "Prediabetic", "Diabetic"],
)

# 4.4 نسبة الأنسولين للجلوكوز (مؤشر مقاومة الأنسولين التقريبي)
df_fe["Insulin_Glucose_Ratio"] = df_fe["Insulin"] / df_fe["Glucose"]

# 4.5 تفاعل بين BMI و DiabetesPedigreeFunction (وراثة + وزن)
df_fe["BMI_Pedigree_Interaction"] = df_fe["BMI"] * df_fe["DiabetesPedigreeFunction"]

# 4.6 عدد الحالات غير الطبيعية (كام قيمة من القيم دي خرجت عن المعدل الطبيعي)
def count_abnormal(row):
    flags = 0
    flags += row["Glucose"] > 125
    flags += row["BloodPressure"] > 90
    flags += row["BMI"] > 30
    flags += row["SkinThickness"] > 40
    return flags

df_fe["Abnormal_Count"] = df_fe.apply(count_abnormal, axis=1)

# 4.7 One-Hot Encoding للأعمدة الفئوية الجديدة
df_fe_encoded = pd.get_dummies(
    df_fe, columns=["AgeGroup", "BMI_Category", "Glucose_Category"], drop_first=True
)

print("\nالأعمدة الجديدة بعد الـ Feature Engineering:")
new_cols = [c for c in df_fe_encoded.columns if c not in df_clean.columns]
print(new_cols)

print(f"\nShape النهائي بعد الـ Feature Engineering: {df_fe_encoded.shape}")

df_fe_encoded.to_csv(f"{OUT_DIR}/diabetes_feature_engineered.csv", index=False)
print(f"✔ الملف النهائي اتحفظ في '{OUT_DIR}/diabetes_feature_engineered.csv'")

print("\n" + "=" * 60)
print("PIPELINE COMPLETE ✅")
print("=" * 60)
